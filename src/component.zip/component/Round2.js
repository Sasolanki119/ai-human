import React, { useState, useEffect } from "react";
import { 
  getFirestore, 
  collection, 
  query, 
  where, 
  getDocs, 
  doc, 
  updateDoc 
} from "firebase/firestore";
import "../style/Round2.css";

const Round2 = () => {
  const db = getFirestore();
  const user = JSON.parse(localStorage.getItem("user")); // Get user data from localStorage

  const [timeLeft, setTimeLeft] = useState(20 * 60);
  const [theme, setTheme] = useState("");
  const [productName, setProductName] = useState("");
  const [isProductSubmitted, setIsProductSubmitted] = useState(false);
  const [productDetails, setProductDetails] = useState({
    description: "",
    marketing: "",
    growth: "",
    audience: "",
  });
  const [isAiAccessible, setIsAiAccessible] = useState(false);
  const [submitDisabled, setSubmitDisabled] = useState(false);
  const [isExternalLinkClicked, setIsExternalLinkClicked] = useState(false);

  const themes = [
    "Sustainability",
    "Health & Wellness",
    "AI & Automation",
    "Education & E-Learning",
  ];

  useEffect(() => {
    alert("Round 2 has started! You have 20 minutes to complete it.");

    const timer = setInterval(() => {
      setTimeLeft((prevTime) => {
        if (prevTime === 60) {
          alert("1 minute remaining! Submit your response soon.");
        }
        if (prevTime <= 1) {
          clearInterval(timer);
          setSubmitDisabled(true);
          alert("Time's up! Submitting is now disabled.");
          return 0;
        }
        return prevTime - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const formatTime = (seconds) => {
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${minutes}:${secs < 10 ? "0" : ""}${secs}`;
  };

  /**
   * Helper function to get the current user's Firestore doc reference.
   * Since you are using the "user" collection with auto-generated IDs,
   * we first query by the email field, then grab the doc ID.
   */
  const getUserDocRef = async () => {
    const userEmail = user.email;
    const userCollectionRef = collection(db, "user"); // Your collection is named "user"
    const q = query(userCollectionRef, where("email", "==", userEmail));
    const querySnapshot = await getDocs(q);

    if (querySnapshot.empty) {
      console.error("User document not found!");
      return null;
    }

    // Return a DocumentReference to the first matching doc
    return doc(db, "user", querySnapshot.docs[0].id);
  };

  const handleProductSubmit = async () => {
    if (productName.trim() === "") {
      alert("Please enter a product name before submitting.");
      return;
    }

    setIsProductSubmitted(true);
    setIsAiAccessible(true);

    // 1. Get the user's document reference
    const userDocRef = await getUserDocRef();
    if (!userDocRef) return; // if no doc found, stop

    // 2. Update Firestore with the product name, theme, etc.
    await updateDoc(userDocRef, {
      round2: {
        productName,
        theme,
        productDetails,
        isProductSubmitted: true,
      },
    });
  };

  const handleSubmitAll = async () => {
    // 1. Get the user's document reference
    const userDocRef = await getUserDocRef();
    if (!userDocRef) return; // if no doc found, stop

    // 2. Update Firestore with the final data
    await updateDoc(userDocRef, {
      round2: {
        productName,
        theme,
        productDetails,
        isProductSubmitted,
        submitDisabled,
      },
    });

    alert("Your response has been sent to the database!");
  };

  const handleExternalLinkClick = () => {
    if (!isExternalLinkClicked) {
      setIsExternalLinkClicked(true);
      window.open("https://chatgpt.com", "_blank"); // Open ChatGPT in a new tab
      setTimeout(() => {
        alert("You have spent 10 minutes on ChatGPT. Returning to your round.");
        window.location.reload(); // Reload the round when the user returns after 10 minutes
      }, 10 * 60 * 1000); // 10 minutes
    }
  };

  return (
    <div className="round2-container">
      <h1>Round 2: Thematic Product Strategy Challenge</h1>
      <div className="timer">Time Left: {formatTime(timeLeft)}</div>

      <div className="note">
        <p>
          <strong>Note:</strong> Select a theme, enter your product name, and
          submit it to unlock AI assistance.
        </p>
      </div>

      <div className="product-info-container">
        <label>Select Theme:</label>
        <select onChange={(e) => setTheme(e.target.value)} value={theme}>
          <option value="">-- Select Theme --</option>
          {themes.map((themeOption) => (
            <option key={themeOption} value={themeOption}>
              {themeOption}
            </option>
          ))}
        </select>

        <label>Enter Product Name:</label>
        <input
          type="text"
          value={productName}
          onChange={(e) => setProductName(e.target.value)}
          disabled={isProductSubmitted}
        />
        <button onClick={handleProductSubmit} disabled={isProductSubmitted}>
          Submit Product
        </button>
      </div>

      <div className="strategy-container">
        {Object.keys(productDetails).map((key) => (
          <div className="strategy-box" key={key}>
            <h3>{key.charAt(0).toUpperCase() + key.slice(1)} Strategy</h3>
            <textarea
              value={productDetails[key]}
              onChange={(e) =>
                setProductDetails({ ...productDetails, [key]: e.target.value })
              }
              placeholder={`Enter ${key} strategy...`}
            />
            <button>Submit</button>
          </div>
        ))}
      </div>

      {/* External Link Button */}
      <div className="external-link-container">
        <button
          className="external-link-button"
          onClick={handleExternalLinkClick}
          disabled={isExternalLinkClicked}
        >
          Go to ChatGPT for 10 minutes
        </button>
      </div>

      <button
        className="main-submit"
        disabled={submitDisabled}
        onClick={handleSubmitAll}
      >
        Submit All
      </button>
    </div>
  );
};

export default Round2;
