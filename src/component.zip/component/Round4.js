import { useState, useEffect } from "react";
import "../style/Round4.css";

const Round4 = () => {
  const [problem, setProblem] = useState("");
  const [aiPrompt, setAiPrompt] = useState("");
  const [aiResponse, setAiResponse] = useState("");
  const [solution, setSolution] = useState("");
  const [aiUsed, setAiUsed] = useState(false);
  const [timeLeft, setTimeLeft] = useState(1800);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const requestAIHelp = async () => {
    if (aiUsed) return;
    setAiUsed(true);
    const response = await fetch("/api/ai-assist", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query: aiPrompt }),
    });
    const data = await response.json();
    setAiResponse(data.aiReply);
  };

  const handleSubmit = async () => {
    await fetch("/api/submit-round4", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ problem, aiResponse, solution }),
    });
    alert("Solution submitted successfully!");
  };

  useEffect(() => {
    if (timeLeft === 0) handleSubmit();
  }, [timeLeft]);

  return (
    <div className="round4-container">
      <h1>Round 4: The Social Bond</h1>
      <div className="timer">Time Left: {Math.floor(timeLeft / 60)}:{(timeLeft % 60).toString().padStart(2, "0")}</div>
      
      <div className="main-container">
        <div className="input-container">
          <textarea
            className="problem-box"
            placeholder="Enter problem statement here..."
            value={problem}
            onChange={(e) => setProblem(e.target.value)}
          ></textarea>
          <textarea
            className="solution-box"
            placeholder="Enter your solution here..."
            value={solution}
            onChange={(e) => setSolution(e.target.value)}
          ></textarea>
        </div>

        <div className="ai-container">
          <textarea
            className="ai-input"
            placeholder="Enter AI prompt here..."
            value={aiPrompt}
            onChange={(e) => setAiPrompt(e.target.value)}
          ></textarea>
          <button onClick={requestAIHelp} disabled={aiUsed} className="ai-btn">{aiUsed ? "AI Response Received" : "Request AI Assistance"}</button>
          {aiUsed && <div className="ai-response">AI Insight: {aiResponse}</div>}
        </div>
      </div>
      
      <button onClick={handleSubmit} className="submit-btn">Submit Solution</button>
    </div>
  );
};

export default Round4;