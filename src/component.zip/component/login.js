import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { db } from "../firebaseConfig"; // Import Firestore
import { collection, getDocs, query, where } from "firebase/firestore";
import "../style/login.css";

const Login = () => {
  const [credentials, setCredentials] = useState({ email: "", password: "" });
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleChange = (e) => {
    setCredentials({ ...credentials, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    if (!credentials.email || !credentials.password) {
      setError("Please enter both email and password.");
      return;
    }

    setLoading(true);
    try {
      // Query the "user" collection for a document where the email matches
      const q = query(
        collection(db, "user"),
        where("email", "==", credentials.email)
      );
      const querySnapshot = await getDocs(q);

      let userFound = null;
      querySnapshot.forEach((doc) => {
        const userData = doc.data();
        if (userData.password === credentials.password) {
          userFound = userData;
        }
      });

      if (userFound) {
        localStorage.setItem("user", JSON.stringify(userFound));
        navigate("/dashboard");
      } else {
        setError("Invalid email or password.");
      }
    } catch (error) {
      console.error("Login Error:", error);
      setError("Error connecting to database. Check Firestore setup.");
    }
    setLoading(false);
  };

  return (
    <div className="login-container">
      <h1>AI-Human Collaboration Challenge</h1>
      <div className="login-box">
        {error && <p className="error-message">{error}</p>}
        <input
          type="email"
          name="email"
          placeholder="Enter Email"
          onChange={handleChange}
          required
        />
        <div className="password-container">
          <input
            type={showPassword ? "text" : "password"}
            name="password"
            placeholder="Enter Password"
            onChange={handleChange}
            required
          />
          <button
            type="button"
            className="toggle-password"
            onClick={() => setShowPassword(!showPassword)}
          >
            {showPassword ? "🙈" : "👁️"}
          </button>
        </div>
        <button onClick={handleSubmit} disabled={loading}>
          {loading ? "Logging in..." : "Log In"}
        </button>
      </div>
    </div>
  );
};

export default Login;
