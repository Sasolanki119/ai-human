import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { 
  getFirestore, 
  doc, 
  getDoc, 
  updateDoc, 
  collection, 
  query, 
  where, 
  getDocs 
} from "firebase/firestore";
import { getAuth } from "firebase/auth";
import "../style/Dashboard.css";

const Dashboard = () => {
  const [rounds, setRounds] = useState([]);
  const navigate = useNavigate();
  const auth = getAuth();
  const db = getFirestore();

  /**
   * Helper function to retrieve the user's Firestore document reference
   * by querying the "user" collection for a matching email.
   */
  const getUserDocRef = async () => {
    const userCollectionRef = collection(db, "user");
    const q = query(userCollectionRef, where("email", "==", auth.currentUser.email));
    const querySnapshot = await getDocs(q);
    if (querySnapshot.empty) {
      console.error("User document not found!");
      return null;
    }
    return doc(db, "user", querySnapshot.docs[0].id);
  };

  // Fetch rounds from Firestore when the component loads
  useEffect(() => {
    const storedUser = localStorage.getItem("user");
    if (!storedUser) {
      navigate("/");
    } else {
      const fetchRounds = async () => {
        const userDocRef = await getUserDocRef();
        if (!userDocRef) {
          console.log("No user document found!");
          return;
        }
        const userDoc = await getDoc(userDocRef);
        if (userDoc.exists()) {
          setRounds(userDoc.data().rounds || []);
        } else {
          console.log("No user data found!");
        }
      };

      fetchRounds();
    }
  }, [navigate, db, auth]);

  const handleNavigation = async (round) => {
    const previousRound = rounds.find(r => r.roundId === round.roundId - 1);
    if (
      round.status === "Locked" ||
      round.status === "Completed" ||
      (previousRound && previousRound.status !== "Completed")
    ) {
      return;
    }

    // Mark round as completed in Firestore when user moves on
    const userDocRef = await getUserDocRef();
    if (!userDocRef) return;
    await updateDoc(userDocRef, {
      [`rounds.${round.roundId - 1}.status`]: "Completed", // Update the status of the round
    });

    navigate(`/round${round.roundId}`);
  };

  const handleLogout = () => {
    localStorage.removeItem("user"); // Clear session
    navigate("/"); // Redirect to login page
  };

  return (
    <div className="dashboard-container">
      <h1>Welcome to Your Dashboard</h1>
      <h2>Round Progress</h2>
      <ul>
        {rounds.map((round) => (
          <li
            key={round.roundId}
            className={`round ${round.status.toLowerCase()}`}
            onClick={() => handleNavigation(round)}
            style={{
              cursor:
                round.status === "Locked" || round.status === "Completed"
                  ? "not-allowed"
                  : "pointer",
            }}
          >
            {round.name} - <strong>{round.status}</strong>
          </li>
        ))}
      </ul>
      <button className="logout-btn" onClick={handleLogout}>
        Logout
      </button>
    </div>
  );
};

export default Dashboard;
