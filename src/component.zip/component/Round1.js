import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { getFirestore } from "firebase/firestore";
import { collection, query, where, getDocs, doc, updateDoc } from "firebase/firestore";
import { getAuth } from "firebase/auth";
import "../style/Round1.css";

const Round1 = () => {
  const navigate = useNavigate();
  const [selectedMovie, setSelectedMovie] = useState("");
  const [customMovie, setCustomMovie] = useState("");
  const [story, setStory] = useState("");
  const [timeLeft, setTimeLeft] = useState(900); // 15 minutes in seconds
  const [submitDisabled, setSubmitDisabled] = useState(false);

  const db = getFirestore();
  const auth = getAuth();

  const movies = ["Inception", "Titanic", "The Matrix", "Interstellar", "Other"];

  // Start a 15-minute countdown on mount
  useEffect(() => {
    alert("Round 1 has started! You have 15 minutes.");

    const timer = setInterval(() => {
      setTimeLeft((prevTime) => {
        if (prevTime === 60) {
          alert("1 minute remaining! Submit your response soon.");
        }
        if (prevTime <= 1) {
          clearInterval(timer);
          setSubmitDisabled(true);
        }
        return prevTime - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  // Handle form submission
  const handleSubmit = async () => {
    if (!selectedMovie || (selectedMovie === "Other" && !customMovie) || !story) {
      alert("Please complete all fields before submitting.");
      return;
    }

    try {
      // 1. Get the user's email
      const userEmail = auth.currentUser?.email;
      if (!userEmail) {
        alert("No user is logged in.");
        return;
      }

      // 2. Query Firestore to find the document matching this email
      const userCollectionRef = collection(db, "user"); // 'user' is your collection name
      const q = query(userCollectionRef, where("email", "==", userEmail));
      const querySnapshot = await getDocs(q);

      if (querySnapshot.empty) {
        console.error("User document not found in Firestore!");
        alert("User document not found!");
        return;
      }

      // 3. Get the document ID for this user
      const userDocRef = doc(db, "user", querySnapshot.docs[0].id);

      // 4. Update the Firestore document
      await updateDoc(userDocRef, {
        "responses.round1": {
          // If "Other" is chosen, store the customMovie name, otherwise use the selected movie
          movie: selectedMovie === "Other" ? customMovie : selectedMovie,
          story: story,
        },
        "rounds.0.status": "Completed", // Mark round 1 as completed
      });

      alert("Your response has been submitted successfully!");
      navigate("/dashboard");
    } catch (error) {
      console.error("Error updating Firestore document:", error);
      alert("There was an error submitting your response.");
    }
  };

  return (
    <div className="round1-container">
      <h1>Round 1: Reel to Real</h1>
      <p className="description">
        Rewrite the plot of a movie by changing key decisions. Choose a movie from the list or add your own.
      </p>

      <div className="movie-selection">
        <label>Select a Movie:</label>
        <select
          value={selectedMovie}
          onChange={(e) => setSelectedMovie(e.target.value)}
        >
          <option value="">-- Select a Movie --</option>
          {movies.map((movie, index) => (
            <option key={index} value={movie}>
              {movie}
            </option>
          ))}
        </select>
        {selectedMovie === "Other" && (
          <input
            type="text"
            placeholder="Enter movie name"
            value={customMovie}
            onChange={(e) => setCustomMovie(e.target.value)}
          />
        )}
      </div>

      <div className="story-writing">
        <label>Rewrite the Movie Plot:</label>
        <textarea
          rows="8"
          placeholder="Write your revised movie story here..."
          value={story}
          onChange={(e) => setStory(e.target.value)}
        ></textarea>
      </div>

      <p className="timer">
        Time Left: {Math.floor(timeLeft / 60)}:
        {(timeLeft % 60).toString().padStart(2, "0")}
      </p>

      <button className="submit-button" onClick={handleSubmit} disabled={submitDisabled}>
        Submit
      </button>
    </div>
  );
};

export default Round1;
